import pandas as pd
import statsmodels.api as sm

# Data Filtering

df = pd.read_csv(r"C:\Hackthon\Problem4\World Indicators.csv")
us = df[df["Country/Region"] == "United States"]
print(us)

# Data Cleaning

us = us[["Year", "Population Total"]].dropna()
print(us)

# Adding a new column
X_us = sm.add_constant(us["Year"])
y_us = us["Population Total"]
print(X_us)
print(y_us)


us_model = sm.OLS(y_us, X_us).fit()
us_2015 = us_model.predict([1, 2015])[0]

print("US Population Model Summary")
print(us_model.summary())
print("\nPredicted US Population in 2015:", us_2015)
print("-" * 60)