import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error
from statsmodels.stats.outliers_influence import variance_inflation_factor


# 1. LOAD DATA

import os
paths_to_try = ['World Indicators.csv', 
                r'C:\Hackthon\Problem4\World Indicators.csv',
                '/mnt/data/World Indicators.csv']
df = None
for p in paths_to_try:
    if os.path.exists(p):
        df = pd.read_csv(p)
        print(f'Loaded data from: {p}')
        break

if df is None:
    raise FileNotFoundError(' World Indicators.csv not found. Please check the file path.')

print(f'\nDataset shape: {df.shape}')
print('\nFirst 5 rows:')
print(df.head())
print('\n Missing values per column:')
print(df.isna().sum())
print('\nStatistical Summary:')
print(df.describe().T)


# 2. US POPULATION MODEL

print('\n' + '='*80)
print('PART 1: US POPULATION PREDICTION')
print('='*80)

# Filter US data
us = df[df['Country/Region'] == 'United States'][['Year', 'Population Total']].dropna()
us['Year'] = pd.to_numeric(us['Year'], errors='coerce')
us = us.dropna(subset=['Year'])

print(f'\n US data rows: {len(us)}')
print('\nFirst 5 rows of US data:')
print(us.head())

# Build linear regression model
X_us = sm.add_constant(us['Year'])
y_us = us['Population Total']
model_us = sm.OLS(y_us, X_us).fit()

print('\nUS Population Model Summary:')
print(model_us.summary())

# Predict for 2015
pred_2015 = model_us.predict([1, 2015])[0]
print(f'\nPredicted US Population in 2015: {pred_2015:,.0f}')

# Visualization
plt.figure(figsize=(10, 6))
plt.scatter(us['Year'], us['Population Total'], label='Observed', alpha=0.6, s=50)
plt.plot(us['Year'], model_us.predict(X_us), label='OLS Fit', color='red', linewidth=2)
plt.xlabel('Year', fontsize=12)
plt.ylabel('Population Total', fontsize=12)
plt.title('US Population Trend (Linear Regression)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()


# 3. EUROPE LIFE EXPECTANCY MODEL

print('\n' + '='*80)
print('PART 2: EUROPE LIFE EXPECTANCY PREDICTION')
print('='*80)

# Select columns
cols = ['Life Expectancy Female', 'Birth Rate', 'GDP', 'Health Exp % GDP', 
        'Infant Mortality Rate', 'Life Expectancy Male']
europe = df[df['Region'] == 'Europe'][cols].copy()

print(f'\n Europe rows before dropna: {europe.shape[0]}')
europe = europe.dropna()
print(f'Europe rows after dropna: {europe.shape[0]}')
print('\nFirst 5 rows of Europe data:')
print(europe.head())

# Correlation Matrix
import seaborn as sns
plt.figure(figsize=(10, 8))
sns.heatmap(europe.corr(), annot=True, fmt='.2f', cmap='coolwarm', 
            square=True, linewidths=0.5, cbar_kws={"shrink": 0.8})
plt.title('Correlation Matrix (Europe)', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()

# 3.1 INITIAL MODEL (All Predictors)

print('\n' + '-'*80)
print('STEP 1: Initial Model with ALL Predictors')
print('-'*80)

Y = europe['Life Expectancy Female']
X_all = europe.drop(columns=['Life Expectancy Female'])
X_all = sm.add_constant(X_all)

model_initial = sm.OLS(Y, X_all).fit()
print('\nInitial Model Summary (All Predictors):')
print(model_initial.summary())

# Check VIF for multicollinearity
print('\nVariance Inflation Factor (VIF) - Checking Multicollinearity:')
vif_df = pd.DataFrame({
    'Feature': X_all.columns,
    'VIF': [variance_inflation_factor(X_all.values, i) for i in range(X_all.shape[1])]
})
print(vif_df)
print('\nNote: VIF > 10 indicates high multicollinearity')

# ========================================
# 3.2 FINAL MODEL (Significant Predictors Only)
# ========================================
print('\n' + '-'*80)
print('STEP 2: Final Model with SIGNIFICANT Predictors Only')
print('-'*80)

# Identify significant predictors (p < 0.05)
print('\nAnalyzing p-values from initial model:')
p_values = model_initial.pvalues
for predictor, p_val in p_values.items():
    if predictor == 'const':
        continue
    status = 'SIGNIFICANT' if p_val < 0.05 else 'NOT SIGNIFICANT'
    print(f'  {predictor:30s}: p = {p_val:.4f} {status}')

# Exclude non-significant predictors (Birth Rate has p=0.578)
significant_predictors = ['GDP', 'Health Exp % GDP', 'Infant Mortality Rate', 'Life Expectancy Male']

print(f'\nSelected significant predictors: {significant_predictors}')

# Build final model
X_final = europe[significant_predictors]
X_final = sm.add_constant(X_final)

model_eu = sm.OLS(Y, X_final).fit()
print('\nFinal Model Summary (Significant Predictors Only):')
print(model_eu.summary())

# 3.3 MODEL EVALUATION

print('\n' + '-'*80)
print('STEP 3: Model Evaluation Metrics')
print('-'*80)

preds = model_eu.predict(X_final)
rmse = np.sqrt(mean_squared_error(Y, preds))
mae = mean_absolute_error(Y, preds)
r2 = model_eu.rsquared

print(f'\nModel Performance:')
print(f'  ✓ RMSE (Root Mean Squared Error): {rmse:.4f} years')
print(f'  ✓ MAE (Mean Absolute Error):      {mae:.4f} years')
print(f'  ✓ R² (R-Squared):                  {r2:.4f} ({r2*100:.2f}% variance explained)')


# 3.4 DIAGNOSTIC PLOTS

print('\n' + '-'*80)
print('STEP 4: Model Diagnostics')
print('-'*80)

residuals = model_eu.resid

# Residuals vs Predicted
plt.figure(figsize=(10, 6))
plt.scatter(preds, residuals, alpha=0.5)
plt.axhline(0, color='red', linestyle='--', linewidth=2, label='Zero Line')
plt.xlabel('Predicted Life Expectancy (Female)', fontsize=12)
plt.ylabel('Residuals', fontsize=12)
plt.title('Residuals vs Predicted Values', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# QQ Plot
sm.qqplot(residuals, line='s')
plt.title('Q-Q Plot of Residuals', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()


# 3.5 PREDICTION FOR NEW COUNTRY

print('\n' + '-'*80)
print('STEP 5: Prediction for Hypothetical Country')
print('-'*80)

# Input values
print('\nInput characteristics:')
print('  • Birth Rate:              3%')
print('  • GDP:                     $1,000,000,000')
print('  • Health Exp % GDP:        4%')
print('  • Infant Mortality Rate:   5 per 1000')
print('  • Life Expectancy Male:    80 years')

# Create test input (only significant predictors)
test_input = pd.DataFrame({
    'const': [1],
    'GDP': [1e9],
    'Health Exp % GDP': [4],
    'Infant Mortality Rate': [5],
    'Life Expectancy Male': [80]
})

predicted_life = model_eu.predict(test_input)[0]
print(f'\nPredicted Life Expectancy (Female): {round(predicted_life, 2)} years')

# 4. OPTIONAL: RANDOM FOREST COMPARISON

print('\n' + '='*80)
print('BONUS: Random Forest Comparison')
print('='*80)

from sklearn.ensemble import RandomForestRegressor

# Remove 'const' column for RF
X_rf = X_final.drop(columns=['const'])

rf = RandomForestRegressor(n_estimators=200, random_state=42, max_depth=10)
rf.fit(X_rf, Y)
rf_pred = rf.predict(X_rf)
rf_rmse = np.sqrt(mean_squared_error(Y, rf_pred))

print(f'\nRandom Forest Performance:')
print(f'  ✓ RMSE: {rf_rmse:.4f} years')

# Feature importance

feature_importance = pd.DataFrame({
    'Feature': X_rf.columns,
    'Importance': rf.feature_importances_
}).sort_values('Importance', ascending=False)

print(f'\nFeature Importance (Random Forest):')
print(feature_importance)

# RF Prediction

rf_test = pd.DataFrame({
    'GDP': [1e9],
    'Health Exp % GDP': [4],
    'Infant Mortality Rate': [5],
    'Life Expectancy Male': [80]
})
rf_predicted = rf.predict(rf_test)[0]
print(f'\nRF Predicted Life Expectancy (Female): {round(rf_predicted, 2)} years')

# 5. FINAL SUMMARY

print('\n' + '='*80)
print('FINAL SUMMARY')
print('='*80)

print('='*80)
print('Analysis Complete!')
print('='*80)