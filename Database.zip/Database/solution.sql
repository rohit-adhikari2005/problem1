-- Problem 1 solution 
SELECT  c.condition_description, COUNT(v.inventory_id) AS books_in_stock FROM Volume v
JOIN Condition_Codes c ON v.condition_code = c.condition_code
WHERE v.sale_id IS NULL      
GROUP BY c.condition_description
ORDER BY books_in_stock DESC;


-- Problem 2 solution 

SELECT 
    c.condition_description,
    SUM(v.selling_price) AS total_sales
FROM Volume v
JOIN Condition_Codes c 
      ON v.condition_code = c.condition_code
WHERE v.sale_id IS NOT NULL       -- only sold books
GROUP BY c.condition_description
ORDER BY total_sales DESC;


-- Problem 3 solution

SELECT 
    a.author_last_first AS author_name,
    w.title AS book_title,
    COUNT(v.inventory_id) AS inventory_in_stock
FROM Volume v
JOIN Book b 
      ON v.ISBN = b.ISBN
JOIN Work w 
      ON b.work_numb = w.work_numb
JOIN Author a 
      ON w.author_numb = a.author_numb
WHERE v.sale_id IS NULL        -- unsold books only
GROUP BY a.author_last_first, w.title
ORDER BY a.author_last_first ASC, w.title ASC;


-- Problem 4 Solution

SELECT 
    b.ISBN,
    w.title,
    p.publisher_name,
    b.edition,
    b.binding,
    b.copyright_year,
    COUNT(v.inventory_id) AS stock_count
FROM Volume v
JOIN Book b 
      ON v.ISBN = b.ISBN
JOIN Work w 
      ON b.work_numb = w.work_numb
JOIN Publisher p 
      ON b.publisher_id = p.publisher_id
WHERE v.sale_id IS NULL          -- books NOT sold yet → in stock
GROUP BY 
    b.ISBN,
    w.title,
    p.publisher_name,
    b.edition,
    b.binding,
    b.copyright_year
ORDER BY 
    p.publisher_name ASC;


-- Problem 5 Solution

SELECT 
    YEAR(s.sale_date)  AS sale_year,
    MONTH(s.sale_date) AS sale_month,
    DAY(s.sale_date)   AS sale_day,
    SUM(v.selling_price) AS total_sales
FROM Sale s
JOIN Volume v
      ON s.sale_id = v.sale_id
WHERE YEAR(s.sale_date) = 2021
GROUP BY 
    YEAR(s.sale_date),
    MONTH(s.sale_date),
    DAY(s.sale_date)
WITH ROLLUP
ORDER BY 
    sale_year,
    sale_month,
    sale_day;

-- Problem 6 solution

SELECT 
    v.inventory_id,
    w.title,
    c.condition_description,
    v.selling_price
FROM Volume v
JOIN Book b 
      ON v.ISBN = b.ISBN
JOIN Work w 
      ON b.work_numb = w.work_numb
JOIN Condition_Codes c 
      ON v.condition_code = c.condition_code
JOIN Sale s
      ON v.sale_id = s.sale_id
WHERE v.selling_price > (
        SELECT AVG(v2.selling_price)
        FROM Volume v2
        JOIN Sale s2 ON v2.sale_id = s2.sale_id
        WHERE YEAR(s2.sale_date) = 2021
          AND MONTH(s2.sale_date) = 7
      )
ORDER BY w.title ASC;

-- Problem 7 Solution

SELECT 
    a.author_last_first AS author_name,
    w.title,
    COUNT(v.inventory_id) AS copies_sold,
    SUM(v.selling_price) AS total_sales
FROM Volume v
JOIN Sale s 
      ON v.sale_id = s.sale_id
JOIN Book b 
      ON v.ISBN = b.ISBN
JOIN Work w 
      ON b.work_numb = w.work_numb
JOIN Author a 
      ON w.author_numb = a.author_numb
WHERE YEAR(s.sale_date) = 2021
  AND MONTH(s.sale_date) = 7
GROUP BY 
    a.author_last_first,
    w.title
ORDER BY 
    copies_sold DESC,
    total_sales DESC;

-- Problem 8
-- 1) Insert the sale record
INSERT INTO sale (customer_id, sale_date, card_number, exp_month, exp_year)
VALUES (3, '2021-11-03', '1234567891014321', 7, 23);

-- 2) Insert the sale item using LAST_INSERT_ID()
INSERT INTO sale_item (sale_id, inventory_id, selling_price)
VALUES (LAST_INSERT_ID(), 67, 125);

-- 3) Update the volume table (mark volume as sold)
UPDATE volume
SET is_sold = 1
WHERE inventory_id = 67;

-- Problem 9 solution
-- 1st insert
INSERT INTO author (author_name)
VALUES ('J. K. Rowling');

SET @author_id = LAST_INSERT_ID();

-- 2nd insert title
INSERT INTO work (title)
VALUES ("Harry Potter and the Sorcerer's Stone");

SET @work_id = LAST_INSERT_ID();
-- then the publisher
INSERT INTO publisher (publisher_name)
VALUES ('Thorndike Press');

SET @publisher_id = LAST_INSERT_ID();

-- insert book record 
INSERT INTO book (
    work_id, 
    isbn, 
    publisher_id, 
    copyright_year, 
    binding, 
    edition
)
VALUES (
    @work_id,
    '978-0-78622-272-8',
    @publisher_id,
    1999,
    'Leather',
    1
);

SET @book_id = LAST_INSERT_ID();


-- Problem 10 solution

-- 1) Delete from volume for all books by Thorndike Press
DELETE FROM volume
WHERE book_id IN (
    SELECT book_id
    FROM book
    JOIN publisher USING (publisher_id)
    WHERE publisher_name = 'Thorndike Press'
);

-- 2) Delete books by Thorndike Press
DELETE FROM book
WHERE publisher_id IN (
    SELECT publisher_id
    FROM publisher
    WHERE publisher_name = 'Thorndike Press'
);

-- 3) Delete the publisher itself
DELETE FROM publisher
WHERE publisher_name = 'Thorndike Press';


