import React, { useState, useEffect } from 'react';
import { Home, Tv, Users, Film, Clock, Calendar, LogOut, Plus, Edit2, Trash2, Save, X } from 'lucide-react';

const API_URL = 'http://localhost:5000/api';

// API Service
const apiCall = async (endpoint, options = {}) => {
  const token = localStorage.getItem('token');
  
  const config = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
  };
  
  try {
    const response = await fetch(`${API_URL}${endpoint}`, config);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'API request failed');
    }
    
    return data;
  } catch (error) {
    throw error;
  }
};

const authAPI = {
  login: (username, password) =>
    apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
};

const createCRUD = (resource) => ({
  getAll: () => apiCall(`/${resource}`),
  create: (data) => apiCall(`/${resource}`, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  update: (id, data) => apiCall(`/${resource}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  delete: (id) => apiCall(`/${resource}/${id}`, { method: 'DELETE' }),
});

const tvshowsAPI = createCRUD('tvshows');
const seasonsAPI = createCRUD('seasons');
const episodesAPI = createCRUD('episodes');
const castAPI = createCRUD('cast');
const crewAPI = createCRUD('crew');
const screentimesAPI = createCRUD('screentimes');

export default function TVShowManagementApp() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [data, setData] = useState({
    tvshows: [],
    seasons: [],
    episodes: [],
    cast: [],
    crew: [],
    screentimes: []
  });
  const [activeTab, setActiveTab] = useState('dashboard');
  const [editingItem, setEditingItem] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({});
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiConnected, setApiConnected] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (token && user) {
      setCurrentUser(JSON.parse(user));
      setApiConnected(true);
      loadAllData();
    }
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [tvshows, seasons, episodes, cast, crew, screentimes] = await Promise.all([
        tvshowsAPI.getAll(),
        seasonsAPI.getAll(),
        episodesAPI.getAll(),
        castAPI.getAll(),
        crewAPI.getAll(),
        screentimesAPI.getAll(),
      ]);
      
      setData({ tvshows, seasons, episodes, cast, crew, screentimes });
      setApiConnected(true);
    } catch (error) {
      console.error('Failed to load data:', error);
      setError('Failed to connect to backend. Make sure Flask server is running on http://localhost:5000');
      setApiConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const response = await authAPI.login(loginForm.username, loginForm.password);
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      setCurrentUser(response.user);
      await loadAllData();
    } catch (error) {
      setError(error.message || 'Login failed. Check if backend is running.');
      setApiConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setCurrentUser(null);
    setActiveTab('dashboard');
    setShowForm(false);
    setEditingItem(null);
  };

  const handleCreate = async (entity, item) => {
    setLoading(true);
    try {
      const apiMap = {
        tvshows: tvshowsAPI,
        seasons: seasonsAPI,
        episodes: episodesAPI,
        cast: castAPI,
        crew: crewAPI,
        screentimes: screentimesAPI
      };
      
      const newItem = await apiMap[entity].create(item);
      setData({ ...data, [entity]: [...data[entity], newItem] });
      setShowForm(false);
      setFormData({});
      setError('');
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (entity, id, updatedItem) => {
    setLoading(true);
    try {
      const apiMap = {
        tvshows: tvshowsAPI,
        seasons: seasonsAPI,
        episodes: episodesAPI,
        cast: castAPI,
        crew: crewAPI,
        screentimes: screentimesAPI
      };
      
      await apiMap[entity].update(id, updatedItem);
      setData({
        ...data,
        [entity]: data[entity].map(item => item.id === id ? { ...item, ...updatedItem } : item)
      });
      setEditingItem(null);
      setFormData({});
      setError('');
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (entity, id) => {
    if (!window.confirm('Are you sure you want to delete this item?')) return;
    
    setLoading(true);
    try {
      const apiMap = {
        tvshows: tvshowsAPI,
        seasons: seasonsAPI,
        episodes: episodesAPI,
        cast: castAPI,
        crew: crewAPI,
        screentimes: screentimesAPI
      };
      
      await apiMap[entity].delete(id);
      setData({
        ...data,
        [entity]: data[entity].filter(item => item.id !== id)
      });
      setError('');
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const openCreateForm = (entity) => {
    setShowForm(true);
    setEditingItem(null);
    setFormData({});
  };

  const openEditForm = (entity, item) => {
    setEditingItem(item);
    setFormData(item);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingItem(null);
    setFormData({});
    setError('');
  };

  const validateForm = (entity) => {
    if (entity === 'tvshows' && (!formData.title || formData.title.trim() === '')) {
      setError('Title is required');
      return false;
    }
    setError('');
    return true;
  };

  const handleSubmit = (entity) => {
    if (!validateForm(entity)) return;
    
    if (editingItem) {
      handleUpdate(entity, editingItem.id, formData);
    } else {
      handleCreate(entity, formData);
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <Tv className="w-16 h-16 mx-auto text-blue-600 mb-4" />
            <h1 className="text-3xl font-bold text-gray-800">TV Show Manager</h1>
            <p className="text-gray-600 mt-2">Sign in to continue</p>
            
            {!apiConnected && (
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  ⚠️ Backend not connected. Make sure Flask server is running on port 5000
                </p>
              </div>
            )}
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
              <input
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin(e)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
                disabled={loading}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin(e)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
                disabled={loading}
              />
            </div>
            
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}
            
            <button
              onClick={handleLogin}
              disabled={loading}
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition disabled:bg-gray-400"
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </button>
          </div>
          
          <div className="mt-6 p-4 bg-gray-50 rounded-lg text-sm">
            <p className="font-semibold text-gray-700 mb-2">Demo Credentials:</p>
            <p className="text-gray-600">Admin: admin / admin123</p>
            <p className="text-gray-600">User: user / user123</p>
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 rounded-lg text-sm">
            <p className="font-semibold text-blue-700 mb-2">🔧 Backend Setup Required:</p>
            <p className="text-blue-600">Run: python app.py</p>
            <p className="text-blue-600">Server: http://localhost:5000</p>
          </div>
        </div>
      </div>
    );
  }

  const TabButton = ({ icon: Icon, label, tab }) => (
    <button
      onClick={() => { setActiveTab(tab); setShowForm(false); setError(''); }}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
        activeTab === tab ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-medium">{label}</span>
    </button>
  );

  const renderTable = (entity, columns) => {
    const items = data[entity];
    const canEdit = currentUser.role === 'admin';

    return (
      <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-800 capitalize">{entity}</h2>
          {canEdit && (
            <button
              onClick={() => openCreateForm(entity)}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              disabled={loading}
            >
              <Plus className="w-4 h-4" />
              Add New
            </button>
          )}
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                {columns.map(col => (
                  <th key={col.key} className="px-4 py-3 text-left text-sm font-semibold text-gray-700">
                    {col.label}
                  </th>
                ))}
                {canEdit && <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {items.length === 0 ? (
                <tr>
                  <td colSpan={columns.length + (canEdit ? 1 : 0)} className="px-4 py-8 text-center text-gray-500">
                    No data available. {canEdit && 'Click "Add New" to create one.'}
                  </td>
                </tr>
              ) : (
                items.map(item => (
                  <tr key={item.id} className="border-t hover:bg-gray-50">
                    {columns.map(col => (
                      <td key={col.key} className="px-4 py-3 text-sm text-gray-800">
                        {item[col.key] || '-'}
                      </td>
                    ))}
                    {canEdit && (
                      <td className="px-4 py-3 text-sm">
                        <div className="flex gap-2">
                          <button
                            onClick={() => openEditForm(entity, item)}
                            className="text-blue-600 hover:text-blue-800"
                            disabled={loading}
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(entity, item.id)}
                            className="text-red-600 hover:text-red-800"
                            disabled={loading}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderForm = (entity, fields) => {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b flex justify-between items-center">
            <h3 className="text-xl font-bold">
              {editingItem ? 'Edit' : 'Create'} {entity.slice(0, -1)}
            </h3>
            <button onClick={closeForm} className="text-gray-500 hover:text-gray-700">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <div className="p-6 space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-500 text-sm">{error}</p>
              </div>
            )}
            
            {fields.map(field => (
              <div key={field.key}>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {field.label} {field.required && <span className="text-red-500">*</span>}
                </label>
                {field.type === 'textarea' ? (
                  <textarea
                    value={formData[field.key] || ''}
                    onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    required={field.required}
                  />
                ) : (
                  <input
                    type={field.type || 'text'}
                    value={formData[field.key] || ''}
                    onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required={field.required}
                  />
                )}
              </div>
            ))}
          </div>
          
          <div className="p-6 border-t flex justify-end gap-3">
            <button
              onClick={closeForm}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              onClick={() => handleSubmit(entity)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
              disabled={loading}
            >
              <Save className="w-4 h-4" />
              {loading ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Tv className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-800">TV Show Manager</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium text-gray-800">{currentUser.username}</p>
              <p className="text-xs text-gray-600 capitalize">{currentUser.role}</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <nav className="bg-white shadow-sm border-t">
        <div className="max-w-7xl mx-auto px-4 py-3 flex gap-2 overflow-x-auto">
          <TabButton icon={Home} label="Dashboard" tab="dashboard" />
          <TabButton icon={Tv} label="TV Shows" tab="tvshows" />
          <TabButton icon={Calendar} label="Seasons" tab="seasons" />
          <TabButton icon={Film} label="Episodes" tab="episodes" />
          <TabButton icon={Users} label="Cast" tab="cast" />
          <TabButton icon={Users} label="Crew" tab="crew" />
          <TabButton icon={Clock} label="Screentimes" tab="screentimes" />
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {loading && activeTab === 'dashboard' && (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">Loading data...</p>
          </div>
        )}

        {!loading && activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg shadow p-6">
              <Tv className="w-12 h-12 text-blue-600 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{data.tvshows.length}</p>
              <p className="text-gray-600">TV Shows</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <Calendar className="w-12 h-12 text-green-600 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{data.seasons.length}</p>
              <p className="text-gray-600">Seasons</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <Film className="w-12 h-12 text-purple-600 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{data.episodes.length}</p>
              <p className="text-gray-600">Episodes</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <Users className="w-12 h-12 text-orange-600 mb-3" />
              <p className="text-3xl font-bold text-gray-800">{data.cast.length}</p>
              <p className="text-gray-600">Cast Members</p>
            </div>
          </div>
        )}

        {activeTab === 'tvshows' && renderTable('tvshows', [
          { key: 'title', label: 'Title' },
          { key: 'description', label: 'Description' }
        ])}

        {activeTab === 'seasons' && renderTable('seasons', [
          { key: 'seasonNumber', label: 'Season #' },
          { key: 'title', label: 'Show Title' },
          { key: 'seasonDescription', label: 'Description' },
          { key: 'dateStarted', label: 'Start Date' },
          { key: 'dateEnded', label: 'End Date' }
        ])}

        {activeTab === 'episodes' && renderTable('episodes', [
          { key: 'episodeNumber', label: 'Episode #' },
          { key: 'episodeTitle', label: 'Title' },
          { key: 'episodeDescription', label: 'Description' },
          { key: 'rating', label: 'Rating' },
          { key: 'datePublished', label: 'Published' }
        ])}

        {activeTab === 'cast' && renderTable('cast', [
          { key: 'actorID', label: 'Actor ID' },
          { key: 'actorsFirstName', label: 'First Name' },
          { key: 'actorsLastName', label: 'Last Name' }
        ])}

        {activeTab === 'crew' && renderTable('crew', [
          { key: 'crewID', label: 'Crew ID' },
          { key: 'firstName', label: 'First Name' },
          { key: 'lastName', label: 'Last Name' },
          { key: 'personDestination', label: 'Role' }
        ])}

        {activeTab === 'screentimes' && renderTable('screentimes', [
          { key: 'actorID', label: 'Actor ID' },
          { key: 'episodeTitle', label: 'Episode' },
          { key: 'roleName', label: 'Role Name' },
          { key: 'roleType', label: 'Role Type' },
          { key: 'startTime', label: 'Start' },
          { key: 'endTime', label: 'End' }
        ])}

        {showForm && activeTab === 'tvshows' && renderForm('tvshows', [
          { key: 'title', label: 'Title', required: true },
          { key: 'description', label: 'Description', type: 'textarea', required: true }
        ])}

        {showForm && activeTab === 'seasons' && renderForm('seasons', [
          { key: 'seasonID', label: 'Season ID', type: 'number', required: true },
          { key: 'seasonNumber', label: 'Season Number', type: 'number', required: true },
          { key: 'title', label: 'Show Title', required: true },
          { key: 'seasonDescription', label: 'Description', type: 'textarea' },
          { key: 'dateStarted', label: 'Start Date', type: 'date', required: true },
          { key: 'dateEnded', label: 'End Date', type: 'date' }
        ])}

        {showForm && activeTab === 'episodes' && renderForm('episodes', [
          { key: 'episodeNumber', label: 'Episode Number', type: 'number', required: true },
          { key: 'episodeTitle', label: 'Title', required: true },
          { key: 'episodeDescription', label: 'Description', type: 'textarea' },
          { key: 'rating', label: 'Rating', type: 'number' },
          { key: 'datePublished', label: 'Published Date', type: 'date' }
        ])}

        {showForm && activeTab === 'cast' && renderForm('cast', [
          { key: 'actorID', label: 'Actor ID', type: 'number', required: true },
          { key: 'actorsFirstName', label: 'First Name', required: true },
          { key: 'actorsLastName', label: 'Last Name', required: true }
        ])}

        {showForm && activeTab === 'crew' && renderForm('crew', [
          { key: 'crewID', label: 'Crew ID', type: 'number', required: true },
          { key: 'firstName', label: 'First Name', required: true },
          { key: 'lastName', label: 'Last Name', required: true },
          { key: 'personDestination', label: 'Role/Position', required: true }
        ])}

        {showForm && activeTab === 'screentimes' && renderForm('screentimes', [
          { key: 'screentimeID', label: 'Screentime ID', type: 'number', required: true },
          { key: 'actorID', label: 'Actor ID', type: 'number', required: true },
          { key: 'episodeNumber', label: 'Episode Number', type: 'number', required: true },
          { key: 'episodeTitle', label: 'Episode Title', required: true },
          { key: 'roleName', label: 'Role Name', required: true },
          { key: 'roleType', label: 'Role Type', required: true },
          { key: 'startTime', label: 'Start Time', type: 'time', required: true },
          { key: 'endTime', label: 'End Time', type: 'time', required: true }
        ])}
      </main>
    </div>
  );
}