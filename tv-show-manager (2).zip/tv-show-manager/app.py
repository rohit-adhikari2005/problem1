from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_bcrypt import Bcrypt
from config import Config
from database import execute_query
from datetime import timedelta

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = Config.JWT_SECRET_KEY
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)

CORS(app)
jwt = JWTManager(app)
bcrypt = Bcrypt(app)

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password required'}), 400
        
        users = execute_query('SELECT * FROM users WHERE username = %s', (username,))
        if not users:
            return jsonify({'error': 'Invalid credentials'}), 401
        
        user = users[0]
        if not bcrypt.check_password_hash(user['password_hash'], password):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        token = create_access_token(identity={'id': user['id'], 'username': user['username'], 'role': user['role']})
        return jsonify({'token': token, 'user': {'id': user['id'], 'username': user['username'], 'role': user['role']}}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_all(table):
    return execute_query(f'SELECT * FROM {table}')

def create_item(table, data):
    columns = ', '.join(data.keys())
    placeholders = ', '.join(['%s'] * len(data))
    values = tuple(data.values())
    item_id = execute_query(f'INSERT INTO {table} ({columns}) VALUES ({placeholders})', values, fetch=False)
    return {'id': item_id, **data}

def update_item(table, id_column, item_id, data):
    set_clause = ', '.join([f'{k} = %s' for k in data.keys()])
    values = tuple(list(data.values()) + [item_id])
    execute_query(f'UPDATE {table} SET {set_clause} WHERE {id_column} = %s', values, fetch=False)
    return {'message': 'Updated successfully'}

def delete_item(table, id_column, item_id):
    execute_query(f'DELETE FROM {table} WHERE {id_column} = %s', (item_id,), fetch=False)
    return {'message': 'Deleted successfully'}

def create_crud_routes(resource, table, id_column='id'):
    @app.route(f'/api/{resource}', methods=['GET'])
    @jwt_required()
    def get_all_items():
        try:
            items = get_all(table)
            return jsonify(items), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route(f'/api/{resource}', methods=['POST'])
    @jwt_required()
    def create():
        try:
            user = get_jwt_identity()
            if user['role'] != 'admin':
                return jsonify({'error': 'Admin access required'}), 403
            data = request.get_json()
            item = create_item(table, data)
            return jsonify(item), 201
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route(f'/api/{resource}/<int:item_id>', methods=['PUT'])
    @jwt_required()
    def update(item_id):
        try:
            user = get_jwt_identity()
            if user['role'] != 'admin':
                return jsonify({'error': 'Admin access required'}), 403
            data = request.get_json()
            result = update_item(table, id_column, item_id, data)
            return jsonify(result), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route(f'/api/{resource}/<int:item_id>', methods=['DELETE'])
    @jwt_required()
    def delete(item_id):
        try:
            user = get_jwt_identity()
            if user['role'] != 'admin':
                return jsonify({'error': 'Admin access required'}), 403
            result = delete_item(table, id_column, item_id)
            return jsonify(result), 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500

create_crud_routes('tvshows', 'tvshow')
create_crud_routes('seasons', 'tvshowseasons', 'id')
create_crud_routes('episodes', 'episode')
create_crud_routes('cast', 'cast')
create_crud_routes('crew', 'crew')
create_crud_routes('screentimes', 'screentime', 'id')

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'Backend is running!'}), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)