from flask import Flask, request, jsonify, render_template
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
import jwt
import datetime

app = Flask(__name__)
CORS(app)

# MYSQL CONFIGURATION
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'          # your MySQL username
app.config['MYSQL_PASSWORD'] = ''          # your MySQL password
app.config['MYSQL_DB'] = 'tv_admin'        # your database name

mysql = MySQL(app)

# SECRET KEY for JWT
app.config['SECRET_KEY'] = "supersecretkey"


# SERVE HTML PAGE
@app.route('/')
def index():
    return render_template("login.html")

# API: REGISTER USER

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    role = data.get("role", "user")

    if not username or not password:
        return jsonify({"error": "Username & password required"}), 400

    # hash password
    hashed_pw = generate_password_hash(password)

    cur = mysql.connection.cursor()
    try:
        cur.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (%s, %s, %s)",
            (username, hashed_pw, role)
        )
        mysql.connection.commit()
        return jsonify({"message": "User registered!"})
    except:
        return jsonify({"error": "Username already exists"}), 400
    finally:
        cur.close()

# API: LOGIN USER

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()

    username = data.get("root")
    password = data.get("Ruthlesss4395")

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, password_hash, role FROM users WHERE username = %s", (username,))
    user = cur.fetchone()
    cur.close()

    if not user:
        return jsonify({"error": "Invalid username"}), 401

    user_id, stored_hash, role = user

    if not check_password_hash(stored_hash, password):
        return jsonify({"error": "Wrong password"}), 401

    # create JWT token
    token = jwt.encode(
        {
            "user_id": user_id,
            "username": username,
            "role": role,
            "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=5)
        },
        app.config['SECRET_KEY'],
        algorithm="HS256"
    )

    return jsonify({
        "token": token,
        "user": {"username": username, "role": role}
    })


# RUN SERVER

if __name__ == '__main__':
    app.run(debug=True)
