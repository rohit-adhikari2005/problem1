CREATE DATABASE tvshow_manager;
USE tvshow_manager;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(128) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default users (passwords are hashed)
INSERT INTO users (username, password_hash, role) VALUES 
('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYIpSVeu1C2', 'admin'),  -- password: admin123
('user', '$2b$12$6VpZqQX8H5JKLp/vYW0sQuOHxH9B4vQXGHYH8tXJKlGXqKZ1xYQoK', 'user');    -- password: user123

-- TV Shows table
CREATE TABLE tvshow (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(128) NOT NULL,
    description VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seasons table
CREATE TABLE tvshowseasons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    seasonID INT UNIQUE NOT NULL,
    showID INT,
    seasonNumber INT NOT NULL,
    seasonDescription VARCHAR(200),
    dateStarted DATE,
    dateEnded DATE,
    title VARCHAR(128),
    FOREIGN KEY (showID) REFERENCES tvshow(id) ON DELETE CASCADE
);

-- Episodes table
CREATE TABLE episode (
    id INT PRIMARY KEY AUTO_INCREMENT,
    episodeNumber INT NOT NULL,
    episodeTitle VARCHAR(128),
    episodeDescription VARCHAR(200),
    rating INT,
    datePublished DATE,
    seasonID INT,
    crewID INT,
    screentimeID INT
);

-- Cast table
CREATE TABLE cast (
    id INT PRIMARY KEY AUTO_INCREMENT,
    actorID INT UNIQUE NOT NULL,
    actorsFirstName VARCHAR(128),
    actorsLastName VARCHAR(128)
);

-- Crew table
CREATE TABLE crew (
    id INT PRIMARY KEY AUTO_INCREMENT,
    crewID INT UNIQUE NOT NULL,
    firstName VARCHAR(128),
    lastName VARCHAR(128),
    personDestination VARCHAR(128)
);

-- Screentime table
CREATE TABLE screentime (
    id INT PRIMARY KEY AUTO_INCREMENT,
    screentimeID INT UNIQUE NOT NULL,
    actorID INT,
    episodeNumber INT,
    episodeTitle VARCHAR(128),
    startTime TIME,
    endTime TIME,
    roleName VARCHAR(128),
    roleType VARCHAR(128)
);

-- Sample data
INSERT INTO tvshow (title, description) VALUES 
('Breaking Bad', 'A high school chemistry teacher turned meth manufacturer');

INSERT INTO tvshowseasons (seasonID, showID, seasonNumber, seasonDescription, dateStarted, dateEnded, title) VALUES 
(1, 1, 1, 'Walter White begins his journey', '2008-01-20', '2008-03-09', 'Breaking Bad');

INSERT INTO episode (episodeNumber, episodeTitle, episodeDescription, rating, datePublished, seasonID) VALUES 
(1, 'Pilot', 'Walter White is diagnosed with cancer', 9, '2008-01-20', 1);

INSERT INTO cast (actorID, actorsFirstName, actorsLastName) VALUES 
(1, 'Bryan', 'Cranston');

INSERT INTO crew (crewID, firstName, lastName, personDestination) VALUES 
(1, 'Vince', 'Gilligan', 'Creator/Writer');

INSERT INTO screentime (screentimeID, actorID, episodeNumber, episodeTitle, startTime, endTime, roleName, roleType) VALUES 
(1, 1, 1, 'Pilot', '00:00:00', '00:58:00', 'Walter White', 'Lead');